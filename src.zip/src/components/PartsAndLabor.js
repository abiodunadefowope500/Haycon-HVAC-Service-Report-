import React from 'react';

export default function PartsAndLabor() {
  return (
    <div className="grid grid-cols-2 gap-2 mb-4">
      <input placeholder="Parts Used" className="border p-2 rounded" />
      <input placeholder="Labor Hours" className="border p-2 rounded" />
    </div>
  );
}