import React, { useRef } from 'react';
import SignaturePad from 'react-signature-canvas';

export default function SignaturePadComp() {
  const sigRef = useRef();
  const clear = () => sigRef.current.clear();

  return (
    <div className="mb-4">
      <h4 className="font-bold mb-2">Signature</h4>
      <SignaturePad ref={sigRef} canvasProps={{className: 'border rounded w-full h-32'}} />
      <button onClick={clear} className="mt-2 bg-gray-600 text-white py-1 px-3 rounded">Clear</button>
    </div>
  );
}