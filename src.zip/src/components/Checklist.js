import React from 'react';

export default function Checklist() {
  const items = ["Filter", "Thermostat", "Refrigerant Levels", "Wiring", "Compressor", "Ductwork"];
  return (
    <div className="grid grid-cols-2 gap-2 mb-4">
      {items.map((item) => (
        <div key={item} className="flex items-center justify-between border p-2 rounded">
          <span>{item}</span>
          <select className="border p-1 rounded">
            <option>OK</option>
            <option>Repair</option>
            <option>N/A</option>
          </select>
        </div>
      ))}
    </div>
  );
}