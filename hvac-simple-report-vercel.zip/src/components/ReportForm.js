import React, { useState } from 'react';
import Checklist from './Checklist';
import Notes from './Notes';
import PartsAndLabor from './PartsAndLabor';
import SignaturePadComp from './SignaturePad';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export default function ReportForm() {
  const [client, setClient] = useState('');
  const [equipment, setEquipment] = useState('');

  const handleExport = async () => {
    const input = document.getElementById('report');
    const canvas = await html2canvas(input);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF();
    pdf.addImage(imgData, 'PNG', 10, 10, 190, 0);
    pdf.save('hvac_report.pdf');
  };

  return (
    <div id="report" className="bg-white shadow rounded-xl p-6">
      <input value={client} onChange={(e) => setClient(e.target.value)} placeholder="Client Name" className="border p-2 rounded mb-2 w-full" />
      <input value={equipment} onChange={(e) => setEquipment(e.target.value)} placeholder="Equipment Details" className="border p-2 rounded mb-4 w-full" />

      <Checklist />
      <Notes />
      <PartsAndLabor />
      <SignaturePadComp />

      <button onClick={handleExport} className="mt-4 bg-blue-600 text-white py-2 px-4 rounded">Export PDF</button>
    </div>
  );
}