import React from 'react';

export default function Notes() {
  return (
    <textarea placeholder="Notes" className="w-full border p-2 rounded mb-4"></textarea>
  );
}